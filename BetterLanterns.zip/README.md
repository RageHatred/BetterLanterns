# Better Lanterns




We're you excited to learn there were new perpetual light sources in the form of the Dvergr lanterns - and then realized they didn't give off nearly enough light?  

Me too; this mod adds a newer, brighter variant of the wall mounted Dvergr Lantern, the Dverger pole lantern, and the handheld Dvergr Lantern. and gives them 4 times the light radius. 